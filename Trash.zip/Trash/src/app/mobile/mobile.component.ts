import { Component } from '@angular/core';

@Component({
   
    selector: 'mobile',
    templateUrl: 'mobile.component.html',
   // styleUrls: ['mobile.component.scss']
})
export class MobileComponent {
    title = 'myApp';
    name='james';
    mycolor='orange';
    products=[
    {id : 1,name:'ajay'},
    {id : 2,name:'anit'},
    {id : 3,name:'elango'},
    {id : 4,name:'vinoth'},
    ];
      changeColor(){
        this.mycolor= this.mycolor==='blue'? 'red': 'blue';
      }
}
