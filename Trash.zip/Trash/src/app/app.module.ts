import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { AppComponent } from './app.component';
//import { TheatreComponentTsComponent } from './theatre-component-ts/theatre-component-ts.component';
import { MobileComponent } from './mobile/mobile.component';
@NgModule({
  declarations: [
    AppComponent,MobileComponent
  ],
  imports: [
    FormsModule,
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent,MobileComponent]
})
export class AppModule { }
