import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  
  styleUrls: ['./app.component.css'],
  //styles: ['h1 { color: red; }']

})
 export class AppComponent {
  title = 'myApp';
  name='james';
  mycolor='yellow';
  products=[
  {id : 1,name:'ajay'},
  {id : 2,name:'anit'},
  {id : 3,name:'elango'},
  {id : 4,name:'vinoth'},
  ];
    changeColor(){
      this.mycolor= this.mycolor==='blue'? 'red': 'blue';
    }
}