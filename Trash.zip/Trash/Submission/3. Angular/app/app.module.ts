import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { AppComponent } from './app.component';

import { MobComponentComponent } from './mob-component/mob-component.component';

@NgModule({
  declarations: [
    AppComponent,MobComponentComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    MobComponentComponent
  ],
  providers: [],
  bootstrap: [AppComponent,MobComponentComponent]
})
export class AppModule { }
