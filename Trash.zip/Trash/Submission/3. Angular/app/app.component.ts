import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  
  styleUrls: ['./app.component.css'],

})
 export class AppComponent {
  title = 'myApp';

  feedback='hello';
  
  mycolor='yellow';

  backgroundcolor = 'black';
  textColor = 'white';
}

//Creating Interface For Flight

export interface Flight {
  flightID: number;
  flightName: string;
  flightNumber: number;
  noOfSeats: number;
  flightType: string;
}