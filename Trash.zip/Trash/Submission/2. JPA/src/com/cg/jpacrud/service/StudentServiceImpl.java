package com.cg.jpacrud.service;

import com.cg.jpacrud.dao.StudentDao;

import com.cg.jpacrud.dao.StudentDaoImpl;
import com.cg.jpacrud.entities.StudentMarks;

public class StudentServiceImpl implements StudentMarksService {

	private StudentDao dao;

	public StudentServiceImpl() {
		dao = new StudentDaoImpl();
	}

	@Override
	public void addStudentMarks(StudentMarks student) {
		dao.beginTransaction();
		dao.addStudent(student);
		dao.commitTransaction();
	}

}
