package com.cg.jpacrud.client;

import java.util.Scanner;
import com.cg.jpacrud.entities.StudentMarks;
import com.cg.jpacrud.service.StudentMarksService;
import com.cg.jpacrud.service.StudentServiceImpl;

public class Client {

	public static void main(String[] args) {

		//Debug this program as Debug -> Debug as Java Application
		
		Scanner input = new Scanner(System.in);
		System.out.println("Welcome To Assessment Management System");
		
		System.out.println("Enter Trainee Name : ");
		String traineeName = input.next();
		
		System.out.println("Enter Module Name : ");
		String moduleName = input.next();

		System.out.println("Enter MPT Score : ");
		int mptScore = input.nextInt();
		
		System.out.println("Enter MTT Score : ");
		int mttScore = input.nextInt();
		
		System.out.println("Enter Assingment Score : ");
		int assingmentScore = input.nextInt();
		
		
		//Calculation Logic Of Total Score is Not Specified
		//Hence, simply adding the scores.
		
		int total = mptScore + mttScore + assingmentScore;
		
		StudentMarks studentMarks = new StudentMarks();
		studentMarks.setTraineeName(traineeName);
		studentMarks.setModuleName(moduleName);
		studentMarks.setMptMarks(mptScore);
		studentMarks.setMttMarks(mttScore);
		studentMarks.setAssingmentMarks(assingmentScore);
		studentMarks.setTotalMarks(total);
		
		StudentMarksService service = new StudentServiceImpl();
		service.addStudentMarks(studentMarks);
		
	}
}
