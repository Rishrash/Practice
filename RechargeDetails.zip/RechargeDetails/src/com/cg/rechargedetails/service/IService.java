package com.cg.rechargedetails.service;

public interface IService {
	public abstract String doRecharge();

}
