package com.cg.rechargedetails.dao;

public interface IQueryMapper {
	public static final String insertQuery = "Insert into recharge_details values(seq_recharge.NEXTVAL,?,?,?,sysdate)";
}
