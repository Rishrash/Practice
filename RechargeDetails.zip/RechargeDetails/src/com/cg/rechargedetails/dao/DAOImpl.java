package com.cg.rechargedetails.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cg.rechargedetails.bean.Customer;

public class DAOImpl implements IDAO {

	@Override
	public boolean makeRecharge(Customer c) throws Exception {
		boolean check = false;
		// TODO Auto-generated method stub
		Connection conn = DBUtil.getConn();
		PreparedStatement pstmt = conn
				.prepareStatement(IQueryMapper.insertQuery);
		pstmt.setString(1, c.getCname());
		pstmt.setLong(2, c.getMnumber());
		pstmt.setInt(3, c.getAmount());
		pstmt.setString(4, c.getPname());
		int n = pstmt.executeUpdate();
		if (n == 1) {
			return true;
		}
		return false;
	}

}
