package com.cg.rechargedetails.dao;

import com.cg.rechargedetails.bean.Customer;

public interface IDAO {
	public abstract boolean makeRecharge(Customer c) throws Exception;

}
