package com.cg.rechargedetails.ui;

public class User {

}
