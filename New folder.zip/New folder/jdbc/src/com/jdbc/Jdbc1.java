package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Jdbc1 {

	public static void main(String[] args) {
		DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
		Connection conn = 
				DriverManager.getConnection (
				"jdbc:oracle:thin:@localhost:1521:xe", "system", "pass");

				// Query the employee details 
				Statement stmt = conn.createStatement(); 

	}

}
