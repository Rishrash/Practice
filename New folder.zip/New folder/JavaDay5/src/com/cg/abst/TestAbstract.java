package com.cg.abst;

public class TestAbstract {

	public static void main(String[] args) 
	{
		//Employee emp=new Employee();
		Employee emp=null;
		emp=new Admin();
		emp.display();
		emp.getData();
	}

}
