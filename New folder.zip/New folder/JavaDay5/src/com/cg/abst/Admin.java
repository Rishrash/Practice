package com.cg.abst;

public class Admin extends Employee {

	@Override
	public void display() {
		System.out.println("display...");
	}

}
