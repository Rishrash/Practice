package com.cg.abst;

public abstract class Employee {
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public abstract void display();
	
	public void getData(){
		System.out.println("getting data....");
	}
}
