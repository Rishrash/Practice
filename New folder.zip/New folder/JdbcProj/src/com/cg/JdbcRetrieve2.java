package com.cg;

import java.sql.*;
import java.util.*;
public class JdbcRetrieve2 {

	public static void main(String[] args) {
		
		try {
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","pass");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("SELECT * FROM vehicle1");
//			ArrayList<Vehicle> vehList=null;
			ArrayList vehList=null;
			vehList=new ArrayList();
			//Vehicle veh=new Vehicle();
			while(rs.next()){
				Vehicle veh=new Vehicle(rs.getInt(2),rs.getString(1));
				/*veh.setvId(rs.getInt(2));
				veh.setvName(rs.getString(1));
				*/vehList.add(veh);
			}
			vehList.add("hello");
			
			//print
			//map(),sort(),
			vehList.stream().forEach(System.out::println);
			for(Object ob:vehList){
				if(ob instanceof Vehicle){
				Vehicle v=(Vehicle)ob;
				System.out.println(v.getvId());
				System.out.println(v.getvName());
				}
				else{
					System.out.println(ob);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
