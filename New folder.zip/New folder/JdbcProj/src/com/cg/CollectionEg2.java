package com.cg;

import java.util.HashMap;
import java.util.Map;

public class CollectionEg2 {

	public static void main(String[] args) {
	
	Empl e1=new Empl(101, "ekta");
	System.out.println(e1);
	Empl e2=new Empl(101, "revanth");
	System.out.println(e2);
	Empl e3=new Empl(102, "pooja");
	System.out.println(e3);
	Empl e4=new Empl(103, "vinod");
	System.out.println(e4);
	e4=null;
	Map<Integer,Empl> empMap=new HashMap();
	empMap.keySet();
	empMap.values();
	empMap.put(e1.geteId(), e1);
	empMap.put(e2.geteId(), e2);
	empMap.put(e3.geteId(), e3);
	empMap.put(e4.geteId(), e4);
	empMap.put(e4.geteId(), e4);
	//hashmap and hash table
	//vector and arraylist and linkedlist
	System.out.println(empMap);
	}

}
class Empl{
	
	public Empl() {
	}
	
	public Empl(int eId, String eName) {
		super();
		this.eId = eId;
		this.eName = eName;
	}

	private int eId;
	private String eName;
	
	public int geteId() {
		return eId;
	}
	public String geteName() {
		return eName;
	}
	public void seteId(int eId) {
		this.eId = eId;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
}
