package com.cg;

import java.sql.*;
public class JdbcRetrieve {

	public static void main(String[] args) {
		
		try {
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","pass");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("SELECT * FROM vehicle1");
			System.out.println(rs.getString(1));
			System.out.println(rs.getInt("id"));
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
