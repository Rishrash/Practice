package com.cg;

//dto - 
//pojo
//bean - implement serializable
//entity bean - hibernate

public class Vehicle {

	public Vehicle(int vId, String vName) {
		super();
		this.vId = vId;
		this.vName = vName;
	}
	private int vId;
	private String vName;
	
	public int getvId() {
		return vId;
	}public String getvName() {
		return vName;
	}
	public void setvId(int vId) {
		this.vId = vId;
	}
	public void setvName(String vName) {
		this.vName = vName;
	}
	public Vehicle() {
		// TODO Auto-generated constructor stub
	}
}
