package com.cg;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class CollectionEg {

	public static void main(String[] args) {
		
		
		
		/*Set<String> s=new LinkedHashSet<>(); //diamond operator
		s.add("hello");
		//s.add(10);
		System.out.println(s);*/
		/*
		Set s=new HashSet();
		Admin admin1=new Admin();
		Admin admin2=new Admin();
		System.out.println(admin1.hashCode());
		System.out.println(admin2.hashCode());
		System.out.println(admin1);//com.cg.Admin@a
		System.out.println(admin2);
		
		s.add(admin1);
		s.add(admin2);
		System.out.println(s);
*//*		Set
		List
		Map*/
		//List l=null;
		//List l=new List();
		//l=new ArrayList();
		
	/*	l.add(new Integer(94));
		l.add(new Integer(90));
		l.add(new Integer(93));
		l.add(new Integer(90));
		l.add(new Integer(56));
		System.out.println("size is : "+l.size());
		
		System.out.println(l.get(0));
		l.set(0,"replaced");
		System.out.println("after changing "+l);
		
		//to iterate still more faster -  use stream API
	 	
		l.stream().forEach(System.out::println);
		
		String arr[]={"mon","tue","wed"};
		//asList
		List l1=Arrays.asList(arr);
		//Arrays.sort()
		l1.stream().forEach(System.out::println);
		
		l.add(null);
		l.add(null);
		
		System.out.println("after adding null "+l);
		
		Set s=new TreeSet();
		//s.add(null);
		//s.add(new Employee());
		s.add(100);
		//s.add("2");
		s.add(2);
		s.add(2);
		s.add(200);
		s.add(3);
		//s.add('2');
		s.add(6);
		s.add(12);
		System.out.println(s);
		//find out to order in desc
		//Collections
		//System.out.println(null);
		s=new HashSet();
		s.add(null);
		s.add(null);
		s.add(null);
		
		System.out.println("after adding null to set "+s+" size "+s.size());
	*/	
		
	}
	
	
	
	

}
class Admin{
	@Override
	public String toString() {
		
		return "Admin is the current class";
	}	
	
	@Override
	public int hashCode() {
		
		return 10;
	}
}

class  Employee implements java.lang.Comparable
{
@Override
public String toString() {
	
	return "empl";
}
	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}