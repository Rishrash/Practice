package com.cg;

public class Program1 {

	String empName;
	
	static public void main(String ... java) {
		
		int id=9001;
		byte b=-128; 
		//int mobile=9876543212;
		long  mobile=9876543212L;
		float pi=3.14f;
		
		boolean status=true;
		char ch='r';
		
		// int to char?
		char ch1=97;
		System.out.println(ch1);
		
		byte b1=90;//1
		int d2=b1;//4by
		
		int y=290;
		byte b2=(byte) y;//data will be either corrupted ot truncated
		
		System.out.println(b2);
		
		
		
		float g=89.556f;
		int d=(int) g;
		System.out.println(d);
		//System.out.println("hello world!!!");
		//System.out.println("this is id of the person : "+id);
		//OCA - String+int =string
		
	}
	
	

}
