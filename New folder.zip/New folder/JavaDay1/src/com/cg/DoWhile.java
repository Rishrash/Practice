package com.cg;

public class DoWhile {

	public static void main(String[] args) {
		
		for(;;)
		{
		System.out.println("in error");
		}
		
		/*int var = 1;
		for (; var < 10; );
		{
			System.out.println(var);
			var++;
		}*/
		
		/*int var = 1;
		for (; var < 10; ) {
			System.out.println("hello");
			var++;
		}*/

		/*
		 * for(init;test;inc/dec){
		 * 
		 * //stmnt }
		 */

		/*
		 * do { System.out.println("hello"); var++; } while(var<5);
		 */

		/*
		 * while(var<10); { System.out.println("hello"); var++; }
		 */
	}

}
