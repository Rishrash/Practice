package com.cg;

public class IfEg {

	public static void main(String[] args) {
		
		int age=44;
		System.out.println(age>18);
		if(age>18)
		{
			System.out.println("welcome");
			System.out.println("u r eligible");
			}
		else
		{
			System.out.println("not eligible");
			System.out.println("as ur age is less than 18");
		}
		
	}

}
