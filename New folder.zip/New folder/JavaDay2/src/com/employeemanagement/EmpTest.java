package com.employeemanagement;

public class EmpTest {

	public static void main(String[] args) {
		
		EmployeeBean emp=new EmployeeBean();
		System.out.println(emp.geteId());
		System.out.println(emp.eId);
	//	System.out.println(emp.empName);
		System.out.println(emp.getEmpName());
		System.out.println(emp.getPassword());
		System.out.println(emp.getDesignation());
		
		emp.setEmpName("ajay");
		System.out.println(emp.getEmpName());
	}

}
