package com.in;

import com.cg.StaticEg;

public class Sampl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticEg s=new StaticEg();
		System.out.println(s.a);
	}

}
