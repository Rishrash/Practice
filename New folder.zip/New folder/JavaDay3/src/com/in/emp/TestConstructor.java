package com.in.emp;

public class TestConstructor {

	public static void main(String[] args) {
		
		StudentBean stud1=new StudentBean();
		System.out.println(stud1.getStudName());
		System.out.println(stud1.getRollNo());
		System.out.println(stud1.getDept());
		StudentBean stud2=new StudentBean();
		System.out.println(stud2.getStudName());
		System.out.println(stud2.getRollNo());
		System.out.println(stud2.getDept());
		StudentBean stud3=new StudentBean(9003,"vinitha","IT");
		System.out.println(stud3.getStudName());
		System.out.println(stud3.getRollNo());
		System.out.println(stud3.getDept());
		StudentBean stud4=new StudentBean(9004,"alex","IT");
		System.out.println(stud4.getStudName());
		System.out.println(stud4.getRollNo());
		System.out.println(stud4.getDept());
	}

}
