package com.in.emp;

public class StringOperation {

	public static void main(String[] args) {
		java.util.Scanner scan=new java.util.Scanner(System.in);
		/*System.out.println("enter id: ");
		int numb=scan.nextInt();
		System.out.println("enter name");
		String n=scan.nextLine();
		System.out.println(n+" "+numb);*/
		String s="hello";//string literals
		/*System.out.println(s);//hello
		System.out.println(s.hashCode());//hello
		s.concat("world");
		System.out.println(s.concat("world"));
		System.out.println(s.concat("world").hashCode());
		System.out.println(s);//hello //immutable
		s.toUpperCase();	
		System.out.println(s);
		*/
		String s1="hello";
		String s2=new String("hello");
		String s3=new String("Hello");
		String s4=new String("Hello");
		String s5=s4;
	/*	System.out.println(s.hashCode());
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		
		System.out.println(s1==s2);//false
		System.out.println(s==s1);//true
		System.out.println(s3==s4);//false
		System.out.println(s5==s4);//true
		System.out.println(s1.equals(s2));//true
		System.out.println(s.equals(s1));//true
	*/
		
		System.out.println("length "+s1.length());
		System.out.println("upper "+s1.toUpperCase());
		//hello
		System.out.println(s1.indexOf('o'));
		System.out.println(s1.substring(0,5));
		System.out.println(s1.lastIndexOf('l'));
		System.out.println(s1.charAt(2));
	//	System.out.println(s1.charAt(6));
		String data="   wel come   ";
		System.out.println(data.trim());
		String content="melcome";
		System.out.println(content.replaceFirst("m", "w"));
		
		String days="mon,tue,wed,thurs,fri,sat,sun";
		String d[]=days.split(",");
		//enhanced for loop
		//src= contain array or collection
		//destination holds only one value
		//for(destination:src){
			
		//}
		/*for(int i=0;i<=d.length;i++){
			System.out.println(d[i]);
		}*/
		
		for(String h:d)
		{
			System.out.println("day is "+h);
		}
		
		String grades="ABCDEF";
		char alpha[]=grades.toCharArray();
		for(char t:alpha)
		{
			System.out.println(t);
		}
		System.out.println("enter name");
		String name=scan.next().toLowerCase();
		//equals ignore case
		System.out.println("enter password");
		String pass=scan.next().toLowerCase();
		if(name.equals("admin") && pass.equals("admin")){
			System.out.println("Logged in !!!!");
		}
		else{
			System.out.println("enter valid credentials");
		}
		String s6="234fs";	
		int i1=Integer.parseInt(s6);
		System.out.println(i1);
		//do while
		//boolean
		//Console - readPassword()
		// enter ip - -1.54.456.567
		//validate its an valid ip ip or not
		//split, method to check range 0-255
		//convert string to integer
	}

}
