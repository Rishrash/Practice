package com.in.emp;

public class StudentBean {

	private int rollNo;
	private String studName;
	private String dept;
	public String getDept() {
		return dept;
	}
	public String getStudName() {
		return studName;
	}
	public int getRollNo() {
		return rollNo;
	}
	public StudentBean() {
		rollNo=9001;
		studName="vinoth";
		dept="CSE";
	System.out.println("in no arg constr");
	}
	public StudentBean(int rollNo, String studName, String dept) {
		
		this.rollNo = rollNo;
		this.studName = studName;
		this.dept = dept;
	}
	
}
