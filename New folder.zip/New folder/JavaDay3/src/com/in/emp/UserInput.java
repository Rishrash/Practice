package com.in.emp;

import java.util.Scanner;

public class UserInput {

	public static void main(String[] args) {
		
		/*Scanner scan=new Scanner("hi-hello how-r u");
		scan.useDelimiter("-");
		*/
		Scanner scan=new Scanner("in Indonesia in india in indiana");
		scan.useDelimiter("in");
		String d1=scan.next();
		System.out.println(d1);
		/*String d2=scan.next();
		System.out.println(d2);
		String d3=scan.next();
		System.out.println(d3);*/
	/*	Scanner scan=new Scanner(System.in);
		System.out.println("enter ur name: ");
		String name=scan.nextLine();
		System.out.println("enter ur id: ");
		int id=scan.nextInt();
		System.out.println("enter ur salary: ");
		float sal=scan.nextFloat();
		System.out.println("name is "+name+" id is "+id);
		System.out.println("salary is "+sal);
	*/	
		/*Scanner scan1=new Scanner(System.in).useDelimiter(";");
		System.out.println("enter ur name: ");
		String data=scan1.next();
		System.out.println(data);
		*/		
	}

}
