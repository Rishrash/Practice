package com.cg;

public class StaticEg {

	static int b;
	public int a;
	static{
		//static initializers
		//initialize the values for static variables
		b=90;
		//a=9000;  //cannot intialize as they belong to diff family
		System.out.println("in static block 1");
	}
	/*static{
		System.out.println("in static block 2");
	}*/
	public static void main(String[] args) {
		
		System.out.println(b);
		System.out.println(StaticEg.b);//recommended
		StaticEg st=new StaticEg();
		System.out.println(st.b);
		System.out.println("in main method");
		
	}
	/*static{
		System.out.println("in static block 3 - after main");
	}*/
}
