package com.cg.inher;

public class Programmer extends Calculator
{
	public void hexaCalculation(){
	System.out.println("hexa ");	
	}
}
