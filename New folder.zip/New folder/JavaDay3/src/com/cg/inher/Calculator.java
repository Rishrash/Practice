package com.cg.inher;

public class Calculator {
	/*private int a,b;
	public int c;
	protected int d;
	private void display(){
		System.out.println("in display");
	}*/
	public void add(){
		System.out.println("addition");
	}
	public void sub(){
		System.out.println("subraction");
	}
}
