package com.cg.inher;

public class TestInheritance {

	public static void main(String[] args) {
	
		//create a obj of ur sub  and call the method of ur base
		Scientific sc=new Scientific();
		sc.add();
		sc.sub();
		sc.sin();
		Programmer p=new Programmer();
		p.add();
		p.sub();
		p.hexaCalculation();
		
		Calculator cl=new Calculator();
		cl.add();
		cl.sub();
	//	cl.sin();
	//	cl.hexaCalculation();
		
		
	}

}
