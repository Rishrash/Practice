package com.cg.inher;

public class Scientific  extends Calculator{

	
	public void sin(){
		/*System.out.println(c);
		System.out.println(d);*/
		//display();
		System.out.println("sin of as number");
	}
	public void add(){
		super.add();
		System.out.println("in sub class");
		System.out.println("logic is different");
		System.out.println("method name is same, arg,return type");
	}
}






