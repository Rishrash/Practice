package com.cg;
import java.lang.*;//default pkg import
public class Client {
	
	public static void main(String[] args) {
		
		StudentBean stud1=new StudentBean();
		//(id,name,pass)
		stud1.setStudId(1006);
		stud1.studName="ajay";
		stud1.setStudPass("ajay123");
		StudentBean stud2=new StudentBean();
		//(id,name,pass)
	
		System.out.println(stud1.getStudId());
		System.out.println(stud1.getStudPass());
		System.out.println(stud1.studName);
		//stud 2
		System.out.println(stud2.getStudId());
		System.out.println(stud2.getStudPass());
		System.out.println(stud2.studName);
		
		//trying to change stud2 data
		stud2.setStudId(1008);
		stud2.setStudPass("raja123");
		stud2.studName="Raja";
		System.out.println(stud2.getStudId());
		System.out.println(stud2.getStudPass());
		System.out.println(stud2.studName);
		
	}

}
