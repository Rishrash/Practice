package com.cg;

public class StaticEg2 {

	int a=1;// 3 copies
	static int b=2;//1 copy
	//static != constant
	public static void main(String[] args) {

		StaticEg2 st1=new StaticEg2();
		StaticEg2 st2=new StaticEg2();
		StaticEg2 st3=new StaticEg2();
		
		System.out.println(++st1.a);//2
		System.out.println(++st2.a);//2
		System.out.println(++st3.a);//2
		//static var
		System.out.println(++st1.b);//3
		System.out.println(++st2.b);//4
		System.out.println(++st3.b);//5
	}

}
