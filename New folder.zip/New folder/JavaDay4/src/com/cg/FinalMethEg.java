package com.cg;


class A{
	
	public final void display(){
		
	}
	
}

class B extends A
{
	
	public void display(){
		
	}
}


public class FinalMethEg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
