package com.cg;

public class Vehicle {
	private int regNo;
	private String vehName;
	public Vehicle() {
		// TODO Auto-generated constructor stub
	}
	
	public Vehicle(int regNo, String vehName) {
		
		this.regNo = regNo;
		this.vehName = vehName;
	}

	public int getRegNo() {
		return regNo;
	}
	public String getVehName() {
		return vehName;
	}
	public void setRegNo(int regNo) {
		this.regNo = regNo;
	}
	public void setVehName(String vehName) {
		this.vehName = vehName;
	}
	
	
	@Override
	public int hashCode() {
		return 6;
	}
	@Override
	public String toString(){
		return "Vehicle class";
	}
	
}
