package com.cg;

public class TestCasting {

	public static void main(String[] args) {
		
		Object ob=new Object();//base
		Employee e=new Employee();//sub//base
		Admin ad=new Admin();//sub 
		
		ob=e;//upward casting(implicit)
		e=ad;//upward casting
		ob=ad;//upward
		
		//downward casting - explicit casting
		
		Employee emp=null;//reference var(base)
		
		emp=new Manager();
		System.out.println(emp);
		if(emp instanceof Manager){
		Manager m=(Manager)emp;
		System.out.println("possible "+m);
		}
		//emp=new Admin();
		//System.out.println(emp);
		else if(emp instanceof Admin){
		Admin ad2=(Admin)emp;
		System.out.println(ad2.hashCode()+" "+emp.hashCode());
		}
		else{
			System.out.println("casting cant be done ");
		}
		System.out.println("normal execution of code");
		
		
		
	}

}
