package com.cg;

public class TrainingInstitute implements IContract
{

	int balance=0;

	@Override
	public void trainingJsp() {
		System.out.println("jsp & servlets training");
		balance=balance-15;
		System.out.println("training over, days left "+balance);
	}

	@Override
	public void trainingJava() {
		balance=IContract.DAYS-15;
		System.out.println("in java training ");
		System.out.println(balance+" days left ");
	}

	
}
