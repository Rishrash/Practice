package com.cg;

public class Demo {

	public static void main(String[] args) {
	
		
		
		String s4=null;
			
		System.out.println(s4.length());
		
		
		
	}
		//create an object of sub class and try to access the methods of base
		/*Demo ob=new Demo();
		System.out.println(ob);
		Demo ob1=new Demo();
		System.out.println(ob1.toString());
		//String st=ob.toString();
		//System.out.println(st);
		Vehicle v=new Vehicle();
		System.out.println(v);
		//ob=ob1;
		if(ob.equals(ob1)){
			System.out.println("both are same");
		}
		else{
		System.out.println("not same");
		}
		System.out.println(ob.hashCode());
		System.out.println(ob1.hashCode());
		System.out.println(v.hashCode());
		
	}
	@Override
	public String toString(){
		return getClass().getName();
	}
	
	@Override
	public int hashCode() {
		
		return 10;
	}
	*/
	
	
	
	
}
