package com.cg;

public class TestOrder {

	public static void main(String[] args) {
		Admin admin=new Admin();
		//Employee e=new Employee();
	}

}
