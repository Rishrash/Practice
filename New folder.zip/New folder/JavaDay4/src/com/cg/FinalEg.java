package com.cg;

public class FinalEg extends Sample {

	public static void main(String[] args) {
		Sample s=new Sample();
		//s.

	}

}
	final class Sample
	{
		
	}