package com.cg;

public class VarArgsEg {

	public static void main(String[] args) {
		
		VarArgsEg ob=new VarArgsEg();
		ob.display();
		//ob.display(null);
		ob.display("hello");
		ob.display("welcome","how");
	}

	void display(String...data){
		System.out.println("in display "+data);
		for(String g:data){
			System.out.println(g);
		}
	}
	
	
}
