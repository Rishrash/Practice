package com.cg;

public class Manager extends Employee{

	
	public void manageWorkers(){
		System.out.println("in first method");
	}
	public void manageWorkers(int a){
		System.out.println();
		System.out.println();
	}
}
