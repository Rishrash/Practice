package com.cg;

public class Employee {
	int id;
	public Employee() {
		
		System.out.println("in base");
	}
	public Employee(int id) {
		
		System.out.println("in base - arg");
	}
}
