package com.cg;

public class Company {

	public static void main(String[] args) {
		//IContract ic=new IContract();
		//object cannot be created
		IContract ob=null;
		ob=new TrainingInstitute();
		ob.trainingJava();
		ob.trainingJsp();
	}

}
