package com.cg;

public class Admin extends Employee{

	public Admin() {
	super(10);
	System.out.println("in admin");
	}
}
