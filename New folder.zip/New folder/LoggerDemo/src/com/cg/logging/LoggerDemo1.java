package com.cg.logging;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;



public class LoggerDemo1 {

	public static void main(String[] args) {

		Logger logg=Logger.getRootLogger();
		logg.info("hi welcome");
		
		Scanner scan=new Scanner(System.in);
		try{
		System.out.println("enter 'a' value :");
		int a=scan.nextInt();
		System.out.println("enter 'b' value :");
		int b=scan.nextInt();
		
		int c=a/b;
		System.out.println("result iS : "+ c);
		}
		catch(InputMismatchException e){
			System.err.println("please enter only numbers");
			logg.error("user entered string "+e.getMessage());
		}
		catch(ArithmeticException e){
			System.err.println();
			logg.error("donot enter b value as zero "+e.getMessage());
		}
		catch(Exception e){
			System.err.println("exception occurred");
			logg.error("problem occured "+e.getMessage());
		}
		finally{
			scan.close();
		}
	}

}
