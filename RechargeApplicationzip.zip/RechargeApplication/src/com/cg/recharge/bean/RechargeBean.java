package com.cg.recharge.bean;
import java.time.*;

public class RechargeBean {
	private int rid;
	private String name;
	private long mobile;
	private String plan;
	private double amount;
	private LocalDate dor;
	
	public int getRid(){
		return rid;
	}
	public void setRid(int rid){
		this.rid=rid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public String getPlan() {
		return plan;
	}
	public void setPlan(String plan) {
		this.plan = plan;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public RechargeBean(){
		
	}
	public RechargeBean(String name, long mobile, String plan, double amount) {
		super();
		this.name = name;
		this.mobile = mobile;
		this.plan = plan;
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "RechargeBean [rid=" + rid + ", name=" + name + ", mobile="
				+ mobile + ", plan=" + plan + ", amount=" + amount + ", dor="
				+ dor + "]";
	}
	
}

