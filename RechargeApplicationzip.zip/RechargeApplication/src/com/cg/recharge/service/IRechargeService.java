package com.cg.recharge.service;

import com.cg.recharge.bean.RechargeBean;
import com.cg.recharge.exception.RechargeProblemException;

public interface IRechargeService {
	public abstract boolean addRechargeDetails(RechargeBean recharge)throws RechargeProblemException;
}
