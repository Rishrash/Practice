package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SecondServlet
 */
@WebServlet("/link2")
public class SecondServlet extends HttpServlet {
	
	PrintWriter  out=null;
	
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
			String qry=request.getQueryString();
			String numb=request.getParameter("numb1");
			String numb1=request.getParameter("numb2");
			out=response.getWriter();
			out.println("qry string is "+qry+" parameter is "+numb+" "+numb1);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
