import { Component } from '@angular/core';

@Component({
  selector: 'nest-tag',
  templateUrl: './nested.component.html'
})
 export class nestedComponent {
  title = 'My Data';
}