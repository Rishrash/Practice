import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {nestedComponent} from './nested.component';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent,nestedComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
 