import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
 // template:'<h1>welocme to my app</h1> <h1>user!!!</h1>',
  
})
 export class AppComponent {
  title = 'myApp';
  content: string = "my content";
}