package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class display
 */
@WebServlet("/display")
public class display extends HttpServlet {
	
	PrintWriter out=null;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	Object ob=request.getAttribute("n");
	String name=(String)ob;
	String city=(String)request.getAttribute("c");
	String mobile=(String)request.getAttribute("m");
	
	
		/*String name1=request.getParameter("uName");
		String city1=request.getParameter("city");
		String mobile1=request.getParameter("mobile");
		*/
		out=response.getWriter();
		out.println("name : "+name);		
		out.println("city : "+city);
		out.println("mobile : "+mobile);
		
	/*	out.println("----from url---");

		out.println("name : "+name1);		
		out.println("city : "+city1);
		out.println("mobile : "+mobile1);
*/	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
