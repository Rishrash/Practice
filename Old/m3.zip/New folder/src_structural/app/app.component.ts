import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
 // template:'<h1>welocme to my app</h1> <h1>user!!!</h1>',
  
})
 export class AppComponent {
  title = 'myApp';
  appStatus: boolean = true;
}