import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  //templateUrl: './app.component.html',
  template:`<div class='cc'>hiii</div> <h1> welocme to my app</h1> <h1>user!!!</h1>
  <div [style.color]="mycolor">supeer!!!</div>
  <div [ngStyle]="myStyles">great!!!</div>
  <button (click)="changeColor()">click</button>

  <input type='text' class='bg'/>
  <input type='text' [ngStyle]="sty2"/>
  <input type='text' class="r"/>
  `,
  styleUrls: ['./app.component.css'],
  styles: ['.r{color:blue}']

})
 export class AppComponent {
  title = 'myApp';
  mycolor='yellow';
  myStyles = {
    'background-color': 'lime',
    'font-size': '20px',
    'font-weight': 'bold'
    }
    sty2={

        'color':'red',
        'background-color':'aquamarine'
    }

    changeColor(){
      this.mycolor= this.mycolor==='blue'? 'red': 'blue';
    }
}