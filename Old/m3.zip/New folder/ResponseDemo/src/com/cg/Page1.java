package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Page1
 */
@WebServlet("/page1")
public class Page1 extends HttpServlet {
	public static int count=1;
	PrintWriter out=null;
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			out=response.getWriter();
			out.println("no of hits on page : "+(++count));
			out.println("the page is redirected in 5 seconds to google");
			response.setHeader("refresh","5;URL=https:\\www.google.com");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
