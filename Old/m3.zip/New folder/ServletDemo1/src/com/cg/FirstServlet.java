package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/myurl")
public class FirstServlet extends HttpServlet {

	PrintWriter out=null;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String number1=request.getParameter("numb1");
		
		int num1=Integer.parseInt(number1);
		int num2=Integer.parseInt(request.getParameter("numb2"));
		out=response.getWriter();
		response.setContentType("text/html");
		out.println("<html><head><title>my page</title></head>");
		out.println("<body><h1><input type='text' value='"+(num1+num2)+"' readonly></h1></body>");
		out.println("</html>");
	/*	if(num>0){
			out.println("<html><head><title>my page</title></head>");
			out.println("<body><h1><input type='text' value='"+msg+"' readonly></h1></body>");
			out.println("</html>");
		}
		else{
			out.println("<html><head><title>my page</title></head>");
			out.println("<body><h1>number is negative</h1></body>");
			out.println("</html>");
		}
	*/	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
