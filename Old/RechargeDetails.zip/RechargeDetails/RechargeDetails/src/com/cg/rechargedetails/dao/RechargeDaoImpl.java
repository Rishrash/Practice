package com.cg.rechargedetails.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.rechargedetails.bean.Customer;
import com.cg.rechargedetails.exception.RechargeProblemException;

public class RechargeDaoImpl implements IRechargeDao {
	Connection conn = null;

	@Override
	public int makeRecharge(Customer c) throws RechargeProblemException {
		// TODO Auto-generated method stub
		int n = 0;
		try {
			conn = DBUtil.getConn();
			PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.INSERTQUERY);
			pstmt.setString(1, c.getCname());
			pstmt.setLong(2, c.getMnumber());
			pstmt.setInt(3, c.getAmount());
			pstmt.setString(4, c.getPname());
			n = pstmt.executeUpdate();
			if (n == 1) {
				pstmt = conn.prepareStatement(IQueryMapper.IDVALUE);
				ResultSet rs = pstmt.executeQuery();
				rs.next();
				n = rs.getInt(1);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RechargeProblemExceeption("problem" + e.getMessage());
		}
		return n;
	}

}
