package com.cg.rechargedetails.dao;

import com.cg.rechargedetails.bean.Customer;
import com.cg.rechargedetails.exception.RechargeProblemException;

public interface IRechargeDao {
	public abstract int makeRecharge(Customer c) throws RechargeProblemException;

}
