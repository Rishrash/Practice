package com.cg.rechargedetails.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	public static Connection getConn() throws SQLException {
		Connection conn = null;

		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		conn = DriverManager.getConnection(
				"jdbc:oracle:thin:@10.219.34.3:1521:orcl", "trg224",
				"training224");
		return conn;
	}

}
