package com.cg.rechargedetails.ui;

import java.util.Scanner;

import com.cg.rechargedetails.bean.Customer;

public class User {

	public static void main(String[] args) {
		System.out.println("---Recharge----");
		System.out.println();
		System.out.println("1. Recharge Details--");;
		System.out.println("2. View Recharge Details");
		System.out.println("Enter your option");
		Scanner scanner = new Scanner(System.in);
		int choice = scanner.nextInt();
		switch(choice) {
		case 1:
			System.out.println("Enter Customer Name");
			String customerName = scanner.next();
			System.out.println("Enter Mobile Number");
			Long mobile = scanner.nextLong();
			System.out.println("Enter the amount");
			int amount = scanner.nextInt();
			System.out.println("Enter Plan Name");
			System.out.println("1. rc99");
			System.out.println("2. rc200");
			System.out.println("3. rc399");
			String planName = scanner.next();
			Customer customer = new Customer();
			customer.setCname(customerName);
			customer.setMnumber(mobile);
			customer.setAmount(amount);
			customer.setPname(planName);
			int status = 0;
			try {
				status = new User().makeRecharge(customer);
			}
			
			
		}
	}

}
