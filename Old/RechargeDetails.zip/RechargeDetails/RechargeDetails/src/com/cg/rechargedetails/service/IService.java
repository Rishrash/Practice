package com.cg.rechargedetails.service;

import com.cg.rechargedetails.bean.Customer;

public interface IService {
	public abstract int makeRecharge(Customer c);

}
