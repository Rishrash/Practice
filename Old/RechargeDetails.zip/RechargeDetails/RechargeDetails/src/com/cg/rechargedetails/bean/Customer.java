package com.cg.rechargedetails.bean;

import java.time.LocalDate;

public class Customer {
	private int rid;
	private String cname;

	private long mnumber;
	private int amount;
	private String pname;
	private LocalDate rdate;

	public int getRid() {
		return rid;
	}

	public void setRid(int rid) {
		this.rid = rid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public long getMnumber() {
		return mnumber;
	}

	public void setMnumber(long mnumber) {
		this.mnumber = mnumber;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public LocalDate getRdate() {
		return rdate;
	}

	public void setRdate(LocalDate rdate) {
		this.rdate = rdate;
	}

	public Customer() {

	}

	public Customer(String cname, long mnumber, int amount, String pname) {
		super();
		this.cname = cname;
		this.mnumber = mnumber;
		this.amount = amount;
		this.pname = pname;
	}

	@Override
	public String toString() {
		return "Customer [rid=" + rid + ", cname=" + cname + ", mnumber=" + mnumber + ", amount=" + amount + ", pname="
				+ pname + ", rdate=" + rdate + "]";
	}
}
