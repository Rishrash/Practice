package com.cg.rechargedetails.exception;

public class RechargeProblemException extends Exception {

	@Override
	public String toString() {
		return "RechargeProblemException";
	}

}
