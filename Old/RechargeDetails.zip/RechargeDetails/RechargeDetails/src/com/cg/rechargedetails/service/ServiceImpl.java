package com.cg.rechargedetails.service;

import com.cg.rechargedetails.bean.Customer;
import com.cg.rechargedetails.dao.RechargeDaoImpl;

public class ServiceImpl implements IService {
	RechargeDaoImpl r = new RechargeDaoImpl();

	@Override
	public int makeRecharge(Customer c) throws Exception {
		// TODO Auto-generated method stub
		return r.makeRecharge(c);
	}

}
