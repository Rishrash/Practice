package com.cg.rechargedetails.dao;

public interface IQueryMapper {
	public static final String INSERTQUERY = "Insert into recharge_details values(seq_recharge.NEXTVAL,?,?,?,sysdate)";
	public static final String IDVALUE = "select seq_recharge.currval from dual";
}
