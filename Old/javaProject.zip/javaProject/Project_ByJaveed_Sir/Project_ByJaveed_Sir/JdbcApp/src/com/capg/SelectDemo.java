package com.capg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectDemo {

	public static void main(String[] args) {


		
		

		//step 1 register driver 
		
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		
			//step 2 get connection
			
	Connection conn =	DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","iit","iit");
		
		//step 3 
		
		
		String select = "select * from employee where id = ?";
				
					
			PreparedStatement pstmt =	conn.prepareStatement(select);
			
			pstmt.setInt(1, 101);
		
		//step 4
		
			ResultSet rs =	pstmt.executeQuery();
			
		while(rs.next()){
			
		int id =	rs.getInt("id");
		String name =	rs.getString(2);
			String addr = rs.getString(3);
			
			System.out.println(id+"  "+name+"  "+addr);
			
		}
		
		
		//step 5
		conn.close();
		
					
	
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		
		
	}

}
