package com.capg;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcDemo {

	public static void main(String[] args) {


		//step 1 register driver 
		
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		
			//step 2 get connection
			
	Connection conn =	DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","iit","iit");
		
		//step 3 
		
					Statement stmt =	conn.createStatement();
					
		String insert = "insert into employee values(101,'king','chennai')";
		
		//step 4
		int n = 	stmt.executeUpdate(insert);
		
		System.out.println(n+" record inserted");
		
		//step 5
		conn.close();
		
					
	
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
