package com.capg;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class PStmtDemo {

	public static void main(String[] args) {


		//step 1 register driver 
		
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		
			//step 2 get connection
			
	Connection conn =	DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","iit","iit");
		
		//step 3 
		
	//String insertQuery = "insert into employee values(?,?,?)";
	
	//String deleteQuery = "delete employee where  name = ? ";
	
	String updateQuery = "update employee set name = ? , address = ? where id = ?";
						
			PreparedStatement pstmt =	conn.prepareStatement(updateQuery);
					
			/*pstmt.setInt(1, 102);
			pstmt.setString(2, "scott");  -- insert
			pstmt.setString(3, "pune");
		*/
		
		//pstmt.setString(1,"king"); -- delete
			
		// positional params consider always left to right... order	
		pstmt.setString(1,"adam");	
		pstmt.setString(2,"hyderabad");
		pstmt.setInt(3,102);		
			
		//step 4
		int n = 	pstmt.executeUpdate();
		
		System.out.println(n+" record update");
		
		//step 5
		conn.close();
		
					
	
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
