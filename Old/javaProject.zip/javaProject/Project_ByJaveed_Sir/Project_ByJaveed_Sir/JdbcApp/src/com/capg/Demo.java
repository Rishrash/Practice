package com.capg;

public class Demo {
	
	
	String getMessage(){
		
		
		return "hii";
		
	}
	
	

}
