package com.capg;

import static org.junit.Assert.*;

import org.junit.Test;

public class DemoTest {

	@Test
	public void testGetMessage() {

			Demo d  = new Demo();
			
		assertEquals("hello", d.getMessage());
		
	}

}
