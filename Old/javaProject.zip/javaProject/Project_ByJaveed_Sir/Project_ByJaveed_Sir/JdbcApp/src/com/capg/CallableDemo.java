package com.capg;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CallableDemo {
	
	
	
	
	public static void main(String[] args) {


		//step 1 register driver 
		
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		
			//step 2 get connection
			
	Connection conn =	DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","iit","iit");
		
		//step 3 
		
					
		CallableStatement cstmt =		conn.prepareCall("{call EPRO}");	
		
		//step 4
		boolean b =	cstmt.execute();
		
	
		System.out.println("is not procedure called ? "+ b);
		
		//step 5
		conn.close();
		
					
	
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

	

}
