package com.capg.ems.dao;

import java.util.ArrayList;

import com.capg.ems.bean.Employee;

public interface EmployeeDAO {
	
	public int    addEmp(Employee e);
	
	public ArrayList<Employee>  displayAll(); 
	
	
}
