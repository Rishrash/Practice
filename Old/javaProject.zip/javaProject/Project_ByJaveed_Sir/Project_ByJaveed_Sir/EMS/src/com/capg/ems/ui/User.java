package com.capg.ems.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.capg.ems.bean.Employee;
import com.capg.ems.service.EmployeeServiceImp;

public class User {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		EmployeeServiceImp service = new EmployeeServiceImp();
		
		System.out.println("**welcome to EMS**");
		System.out.println("1.Add Emp");
		System.out.println("2.Display Employees");
		
		int choice = sc.nextInt();
		
		
		
		switch (choice) {
		case 1:
			
			System.out.println("Enter EID");
			int eid =	sc.nextInt();  // reading data from K.B use local var name same as column name or instance var 
		
			System.out.println("Enter EName");
			String ename = sc.next();
			System.out.println("Enter Sal");
			double sal = sc.nextDouble();
			
			Employee e  = new Employee();
			
			e.setEid(eid);
			e.setEname(ename);
			e.setSal(sal);
			
		int n =	service.addEmp(e);
			
		
		System.out.println(n+" emp added");
		
			break;

		case 2:
			
		ArrayList<Employee> listEmp =		service.displayAll();
		
		
			for (Employee emp : listEmp) {
				
				
				System.out.println(emp.getEid()+"  "+emp.getEname()+" "+emp.getSal());
				
				
			}
		
			
		default:
			break;
		}
			
		
		
		

	}

}
