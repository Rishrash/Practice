package com.capg.ems.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capg.ems.bean.Employee;

public class EmployeeTest {
	
	Employee e = new Employee();

	@Test
	public void testGetEid() {
		
			e.setEid(101);
			
			assertEquals(101,e.getEid());

	}

	@Test
	public void testGetEname() {
		
			e.setEname("king");

				assertNotEquals("scott", e.getEname());
				

	}

	@Test
	public void testGetSal() {


	}

}
