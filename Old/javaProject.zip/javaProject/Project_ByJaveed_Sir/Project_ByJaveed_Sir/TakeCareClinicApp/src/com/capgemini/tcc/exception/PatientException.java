package com.capgemini.tcc.exception;

public class PatientException extends Exception {

	private static final long serialVersionUID = 12121212L;

	public PatientException(String message) {
		super(message);
	}


}
