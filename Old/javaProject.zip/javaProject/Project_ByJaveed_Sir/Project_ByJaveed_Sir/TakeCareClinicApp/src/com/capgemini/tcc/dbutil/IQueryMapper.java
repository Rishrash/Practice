package com.capgemini.tcc.dbutil;

public interface IQueryMapper {
	public final String URL="jdbc:oracle:thin:@localhost:orcl";
	public final String USERNAME="system";
	public final String PASSWORD="admin";
	
	public final String PATIENT_INSERT_QUERY="INSERT INTO PATIENT VALUES(PATIENT_ID_SEQ.NEXTVAL,?,?,?,?,SYSDATE)";
	public final String PATIENT_ID_QUERY_SEQUENCE="SELECT PATIENT_ID_SEQ.CURRVAL FROM DUAL";
	public final String PATIENT_SELECTBYID_QUERY="SELECT * FROM PATIENT WHERE PATIENT_ID=?";
	
}
