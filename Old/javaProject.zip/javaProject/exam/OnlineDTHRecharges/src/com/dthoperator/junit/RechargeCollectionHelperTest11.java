/*******Author Name:Md. Rawoof Ahmed Emp Id : 150936 Date: 5.7.2018 ******/
//Purpose: To provide junit test cases

package com.dthoperator.junit;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.dthoperator.bean.RechargeDetails;
import com.dthoperator.service.RechargeCollectionHelper;

public class RechargeCollectionHelperTest11 {
	//adding asset details to the array list
	@Before
	public void setUp() throws Exception {

	}
	//clearing the arraylist
	@After
	public void tearDown() throws Exception {

	}
	//checking whether asset details are present in array list
	@Test
	public void testaddRechargeDetails() {

		RechargeCollectionHelper helper = new RechargeCollectionHelper();
		RechargeDetails details = new RechargeDetails();
		details.setDthOperator("Airtel");
		helper.addRechargeDetails(details);
		assertEquals(5, helper.getAllDetails().size());

	}
	//checking whether asset details are present in array list
	@Test
	public void testgetItems() {
		RechargeCollectionHelper helper = new RechargeCollectionHelper();
		ArrayList<RechargeDetails> list = helper.getAllDetails();

		assertEquals(false, list.isEmpty());

	}
	//checking whether asset details are present in array list
	@Test
	public void testgetItems1() {
		RechargeCollectionHelper helper = new RechargeCollectionHelper();
		ArrayList<RechargeDetails> list = helper.getAllDetails();
		assertEquals("Airtel", list.get(0).getDthOperator());

	}

	//checking whether asset details are present in array list
	@Test
	public void testgetItems2() {
		RechargeCollectionHelper helper = new RechargeCollectionHelper();
		ArrayList<RechargeDetails> list = helper.getAllDetails();
		assertEquals("Yearly", list.get(1).getRechargePlan());

	}
	//checking whether asset details are present in array list
	@Test
	public void testgetItems3() {
		RechargeCollectionHelper helper = new RechargeCollectionHelper();
		ArrayList<RechargeDetails> list = helper.getAllDetails();
		assertEquals(650, list.get(2).getAmount());

	}
	//checking whether asset details are present in array list
	@Test
	public void testaddRechargeDetails1() {

		RechargeCollectionHelper helper = new RechargeCollectionHelper();
		RechargeDetails details = new RechargeDetails();
		details.setDthOperator("TATASky");
		helper.addRechargeDetails(details);
		assertEquals("TATASky", helper.getAllDetails().get(3).getDthOperator());

	}
	//checking whether asset details are present in array list
	@Test
	public void testgetItems4() {
		RechargeCollectionHelper helper = new RechargeCollectionHelper();
		ArrayList<RechargeDetails> list = helper.getAllDetails();
		assertEquals("DishTV", list.get(1).getDthOperator());

	}
	//checking whether asset details are present in array list
	@Test
	public void testgetItems5() {
		RechargeCollectionHelper helper = new RechargeCollectionHelper();
		ArrayList<RechargeDetails> list = helper.getAllDetails();
		assertEquals("Reliance", list.get(2).getDthOperator());

	}
	@Test
	public void testgetItems6() {
		RechargeCollectionHelper helper = new RechargeCollectionHelper();
		ArrayList<RechargeDetails> list = helper.getAllDetails();
		assertEquals("Monthly", list.get(0).getRechargePlan());

	}
	//checking whether asset details are present in array list
	@Test
	public void testgetItems7() {
		RechargeCollectionHelper helper = new RechargeCollectionHelper();
		ArrayList<RechargeDetails> list = helper.getAllDetails();
		assertEquals("Quarterly", list.get(2).getRechargePlan());

	}
}
