/*******Author Name:Md. Rawoof Ahmed Emp Id : 150936 Date: 5.7.2018 ******/
//Purpose: To provide collections and story data using array list 


package com.dthoperator.service;

import java.util.ArrayList;

import com.dthoperator.bean.RechargeDetails;

public class RechargeCollectionHelper {

	public static ArrayList<RechargeDetails> list;
	//creating array list and adding default data
	static {
		list = new ArrayList<>();

		list.add(new RechargeDetails("Airtel", 1089343431, "Monthly", 210, 4567));
		list.add(new RechargeDetails("DishTV", 303322123, "Yearly", 1260, 2345));
		list.add(new RechargeDetails("Reliance", 892343430, "Quarterly", 650,
				1234));
	}
	//adding recharges details details to the array list

	public void addRechargeDetails(RechargeDetails rechargeDetails) {

		System.out.println("Adding Details...");

		list.add(rechargeDetails);

	}

	//displaying all recharges details

	public void displayRechargeDetails(int transactionID) {

		for (RechargeDetails rechargeDetails : list)
			System.out.println(rechargeDetails);
	}
	public ArrayList<RechargeDetails> getAllDetails()
	{
		return list;
		
	}
}
