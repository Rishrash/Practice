/*******Author Name:Md. Rawoof Ahmed Emp Id : 150936 Date: 5.7.2018 ******/
//Purpose: To provide Exceptions

package com.dthoperator.exception;

public class RechargeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RechargeException() {
		// TODO Auto-generated constructor stub
	}

	public RechargeException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
