package com.cg.learning.staticdb;

import java.util.HashMap;


import com.cg.learning.beans.Product;

public class productDB {
	static HashMap<Integer, Product> productIdMap = getProductIdMap();
	
	static {
		if (productIdMap == null) {
			productIdMap = new HashMap<Integer, Product>();
			Product indiaproduct = new Product(1, "tv", 1000);
			Product chinaproduct = new Product(4, "fridge", 2000);
			Product nepalproduct = new Product(3, "Ac", 800);
			Product bhutanproduct = new Product(2, "fan", 700);

			productIdMap.put(1, indiaproduct);
			productIdMap.put(4, chinaproduct);
			productIdMap.put(3, nepalproduct);
			productIdMap.put(2, bhutanproduct);
		}

	}
	
	public static HashMap<Integer, Product> getProductIdMap() {
		return productIdMap;
	}
}
