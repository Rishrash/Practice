package com.cg.learning.dao;

import java.util.List;

import com.cg.learning.beans.Product;

public interface IProductDAO {
	public List<Product> getAllProducts();
	public Product getProduct(int id);
	public Product addProduct(Product product);
	
}
