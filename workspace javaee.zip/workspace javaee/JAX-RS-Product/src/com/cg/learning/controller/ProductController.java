package com.cg.learning.controller;

import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cg.learning.beans.Product;
import com.cg.learning.service.ProdService;
import com.cg.learning.service.IProdService;

/**
 * 
 * @author yvalecha Controller mapping different HTTP methods, supporting Media
 *         type as JSON
 */
@Path("/products")
public class ProductController {
	IProdService prodService;

	public ProductController() {
		prodService = new ProdService();
	}

	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getProduct() {
		List<Product> listOfProd = prodService.getAllProducts();
		return listOfProd;
	}

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Product getProductById(@PathParam("id") int id) {
		return prodService.getProduct(id);
	}

	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Product addCountry(@FormParam("txtId") int txtId,
			@FormParam("txtName") String txtName,
			@FormParam("price") float price) {
		Product prod = new Product();
		prod.setpId(txtId);
		prod.setpName(txtName);
		prod.setPrice(price);
		return prodService.addProduct(prod);
	}

	
	

}
