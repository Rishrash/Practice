

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FirstServlet
 */
@WebServlet("FirstServlet")
public class FirstServlet extends HttpServlet {
	PrintWriter out =null;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FirstServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String number  = request.getParameter("num");
		int num = Integer.parseInt(number);
		out = response.getWriter();
		response.setContentType("text/html");
		//response.setContentType("text/plain");
		if(num>0){
			out.println("<html><head><title>Sample</title></head><body>");
			out.println("<h1>number is +ve</h1>");
			out.println("</body></html>");
			//out.println("No is positive");
		}
		else{
			out.println("<html><head><title>Sample</title></head><body>");
			out.println("<h1>number is -ve</h1>");
			out.println("</body></html>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
