import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class P1
 */
@WebServlet("P1")
public class P1 extends HttpServlet {
	PrintWriter out = null;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("electronics");
		out = response.getWriter();
		if ("ac".equals(action)) {
			out.println("<html> <body> This is AC </body> </html>");
		} else if ("oven".equals(action)) {
			out.println("<html> <body> This is OVEN </body> </html>");
		} else if ("phone".equals(action)) {
			out.println("<html> <body> This is PHONE </body> </html>");
		} else if ("radio".equals(action)) {
			out.println("<html> <body> This is RADIO </body> </html>");
		} else if ("tv".equals(action)) {
			out.println("<html> <body> This is TV </body> </html>");
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
