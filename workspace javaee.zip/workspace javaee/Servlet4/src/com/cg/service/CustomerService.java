package com.cg.service;

import com.cg.bean.Customer;
import com.cg.dao.CustomerDao;
import com.cg.dao.ICustomerDao;

public class CustomerService implements ICustomerService {
	ICustomerDao custDao = null;

	@Override
	public boolean addCustomer(Customer cg) {
		custDao = new CustomerDao();
		// TODO Auto-generated method stub
		return custDao.addCustomer(cg);
	}

}
