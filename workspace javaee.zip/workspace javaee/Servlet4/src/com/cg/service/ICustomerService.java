package com.cg.service;

import com.cg.bean.Customer;

public interface ICustomerService {
	boolean addCustomer(Customer cg);
}
