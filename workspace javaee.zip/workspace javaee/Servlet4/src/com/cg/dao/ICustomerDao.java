package com.cg.dao;

import com.cg.bean.Customer;

public interface ICustomerDao {
	boolean addCustomer(Customer cg);

}
