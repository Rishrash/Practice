package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.Customer;

public class CustomerDao implements ICustomerDao {
	ArrayList<Customer> custList = null;

	@Override
	public boolean addCustomer(Customer cg) {
		// TODO Auto-generated method stub
		custList = new ArrayList<>();
		return false;
	}

}
